import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;



public class E8 extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter pw = resp.getWriter();
        ServletContext sc = getServletContext();
        String c=(String)sc.getInitParameter("college");
        pw.print("welcome, "+c);
    }
    
}
