

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Pr7 extends HttpServlet {

    int counter;
    @Override
    public void init(ServletConfig cf) throws ServletException {
        counter = Integer.parseInt(cf.getInitParameter("counter"));
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter pw = resp.getWriter();
        counter ++;
        pw.print("counter : "+counter);
    }


}
