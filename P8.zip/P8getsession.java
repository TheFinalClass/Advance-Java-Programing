import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class P8getsession extends HttpServlet {
    
    
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter pw = resp.getWriter();
        HttpSession s= req.getSession(false);
        String name = (String)s.getAttribute("uname");
        pw.print("welcome, "+name);
    }
    
}
