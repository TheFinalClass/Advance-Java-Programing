import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class P8_Bgetsession extends HttpServlet {
    
     @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter pw = resp.getWriter();
        Cookie c[]=req.getCookies();
        pw.print("Cookie is: "+c[0].getValue());
    }

}
