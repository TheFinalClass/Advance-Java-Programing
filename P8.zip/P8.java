import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;



public class P8 extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        HttpSession s= req.getSession();
        String un = req.getParameter("uname");
        s.setAttribute("uname",un);
        resp.sendRedirect("P8getsession");
    }
    
}
